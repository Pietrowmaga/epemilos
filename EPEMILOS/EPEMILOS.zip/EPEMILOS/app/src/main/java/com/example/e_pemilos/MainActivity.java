package com.example.pemilos;  // <-- SESUAIKAN DENGAN PACKAGE KAMU!

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    // Deklarasi Variabel
    TextInputEditText etNama, etKelas, etToken;
    Button btnMasuk;
    ImageView imgKotakSuara;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi (Menghubungkan dengan XML)
        etNama = findViewById(R.id.etNama);
        etKelas = findViewById(R.id.etKelas);
        etToken = findViewById(R.id.etToken);
        btnMasuk = findViewById(R.id.btnMasuk);
        imgKotakSuara = findViewById(R.id.imgKotakSuara);

        // --- TOMBOL MASUK ---
        btnMasuk.setOnClickListener(v -> {
            String nama = etNama.getText().toString().trim();
            String kelas = etKelas.getText().toString().trim();
            String token = etToken.getText().toString().trim();

            // Validasi: Cek apakah ada yang kosong
            if (nama.isEmpty()) {
                etNama.setError("Nama harus diisi!");
                etNama.requestFocus();
            } else if (kelas.isEmpty()) {
                etKelas.setError("Kelas harus diisi!");
                etKelas.requestFocus();
            } else if (token.isEmpty()) {
                etToken.setError("Token harus diisi!");
                etToken.requestFocus();
            } else {
                // Jika semua terisi, lanjutkan (contoh: tampilkan pesan sukses)
                Toast.makeText(MainActivity.this,
                        "Selamat Datang, " + nama + " dari " + kelas,
                        Toast.LENGTH_SHORT).show();

                // Nanti di sini kode untuk pindah ke halaman Voting
                // Intent intent = new Intent(MainActivity.this, VotingActivity.class);
                // intent.putExtra("NAMA", nama);
                // startActivity(intent);
            }
        });

        // --- ICON KOTAK SUARA (Ke Halaman Admin) ---
        imgKotakSuara.setOnClickListener(v -> {
            // Pindah ke AdminActivity
            Intent intent = new Intent(MainActivity.this, AdminActivity.class);
            startActivity(intent);
        });
    }
}